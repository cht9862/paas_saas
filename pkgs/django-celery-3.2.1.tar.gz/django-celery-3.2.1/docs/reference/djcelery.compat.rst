=================================
 Compatibility - djcelery.compat
=================================

.. contents::
    :local:
.. currentmodule:: djcelery.compat

.. automodule:: djcelery.compat
    :members:
    :undoc-members:
