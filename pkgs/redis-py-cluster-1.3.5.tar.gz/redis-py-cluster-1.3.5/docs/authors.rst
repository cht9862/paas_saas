Project Authors
===============

Added in the order they contributed.

If you are mentioned in this document and want your row changed for any reason, open a new PR with changes.

Lead author and maintainer: Grokzen - https://github.com/Grokzen

Authors who contributed code or testing:

 - Dobrite - https://github.com/dobrite
 - 72squared - https://github.com/72squared
 - Neuron Teckid - https://github.com/neuront
 - iandyh - https://github.com/iandyh
 - mumumu - https://github.com/mumumu
 - awestendorf - https://github.com/awestendorf
 - Ali-Akber Saifee - https://github.com/alisaifee
 - etng - https://github.com/etng
 - gmolight - https://github.com/gmolight
 - baranbartu - https://github.com/baranbartu
 - monklof - https://github.com/monklof
 - dutradda - https://github.com/dutradda
 - AngusP - https://github.com/AngusP
 - Doug Kent - https://github.com/dkent
 - VascoVisser - https://github.com/VascoVisser
 - astrohsy - https://github.com/astrohsy
 - Artur Stawiarski - https://github.com/astawiarski
 - Matthew Anderson - https://github.com/mc3ander
