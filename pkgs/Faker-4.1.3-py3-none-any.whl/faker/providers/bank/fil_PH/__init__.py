from ..en_PH import Provider as EnPhBankProvider


class Provider(EnPhBankProvider):
    """No difference from Bank Provider for en_PH locale"""
    pass
